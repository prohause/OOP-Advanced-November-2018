﻿namespace P01_Logger.Layouts.Contracts
{
    public interface ILayout
    {
        string Format
        {
            get;
        }
    }
}