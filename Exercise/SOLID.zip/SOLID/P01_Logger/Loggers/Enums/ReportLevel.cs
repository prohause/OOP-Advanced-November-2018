﻿namespace P01_Logger.Loggers.Enums
{
    public enum ReportLevel
    {
        INFO = 1,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}