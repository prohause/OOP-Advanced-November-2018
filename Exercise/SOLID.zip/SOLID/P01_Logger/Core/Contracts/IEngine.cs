﻿namespace P01_Logger.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}